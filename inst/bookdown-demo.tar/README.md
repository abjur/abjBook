[![Travis-CI Build Status](https://travis-ci.org/abjur/<nome>.svg?branch=master)](https://travis-ci.org/abjur/<nome>)

Exemplo de template bookdown para a ABJ.

