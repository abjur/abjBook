#!/bin/sh

Rscript -e "rmarkdown::render_site(encoding = 'UTF-8')"
